# See canvas document for full constitution content
